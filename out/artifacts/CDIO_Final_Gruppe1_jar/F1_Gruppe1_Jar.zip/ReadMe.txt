For at Jar filen skal virke, skal "src" være samme sted 
som jar filen.

Bemærk at der er nogle fejl med tegnene i spillet.

